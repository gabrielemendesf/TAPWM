let idades = [];
    let opinioes = [];
    let mulheres = 0;
    let homens = 0;
    const totalPessoas = 45; 

    function adicionarResposta() {
      if (idades.length >= totalPessoas) {
        alert("Você já recebeu todas as respostas!");
        return;
      }

      const idade = parseInt(prompt("Digite a idade:"));
      const sexo = prompt("Digite o sexo (F/M):");
      const opiniao = parseInt(prompt("Digite a opinião (1=Péssimo, 2=Regular, 3=Bom, 4=Ótimo):"));
      
      idades.push(idade);
      opinioes.push(opiniao);
      
      if (sexo.toUpperCase() === 'F') {
        mulheres++;
      } else if (sexo.toUpperCase() === 'M') {
        homens++;
      } else {
        alert("Sexo inválido! Use F para feminino ou M para masculino.");
        return;
      }
      
      calcularEstatisticas();
    }

    function calcularEstatisticas() {
      const somaIdades = idades.reduce((total, idade) => total + idade, 0);
      const mediaIdade = somaIdades / idades.length;
      document.getElementById('mediaIdade').textContent = mediaIdade.toFixed(2);

      const idadeMaisVelha = Math.max(...idades);
      document.getElementById('idadeMaisVelha').textContent = idadeMaisVelha;

      const idadeMaisNova = Math.min(...idades);
      document.getElementById('idadeMaisNova').textContent = idadeMaisNova;
      
      const qtdPessimo = opinioes.filter(opiniao => opiniao === 1).length;
      document.getElementById('qtdPessimo').textContent = qtdPessimo;
      
      const qtdOtimoBom = opinioes.filter(opiniao => opiniao >= 3).length;
      const porcentagemOtimoBom = (qtdOtimoBom / opinioes.length) * 100;
      document.getElementById('porcentagemOtimoBom').textContent = porcentagemOtimoBom.toFixed(2) + '%';

      document.getElementById('numMulheres').textContent = mulheres;
      document.getElementById('numHomens').textContent = homens;
    }